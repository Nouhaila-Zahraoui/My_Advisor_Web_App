function ForbiddenAccess() {

    return (
        <h1>Error 403</h1>
        );
}
export default ForbiddenAccess;