import React from 'react';
import './Login.scss';
import Navigation from "../../../components/Navigation";


const Login = () => {

    return (
        <div className="home" >
            <Navigation></Navigation>
        </div>
    )
}

export default Login;