// src/enums/Role.js

const Role = {
    BUSINESS: 'BUSINESS',
    ADMIN: 'ADMIN',
    USER: 'USER',
};

export default Role;
