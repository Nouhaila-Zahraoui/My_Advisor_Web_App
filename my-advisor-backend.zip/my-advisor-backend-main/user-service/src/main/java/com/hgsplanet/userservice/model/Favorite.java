package com.hgsplanet.userservice.model;

import lombok.Data;

@Data
public class Favorite {
    private String accountUsername;
    private String favoriteUsername;
}
