package com.hgsplanet.userservice.enums;

public enum RelationWithUser {
    TOURIST, HABITANT, EX_HABITANT
}
