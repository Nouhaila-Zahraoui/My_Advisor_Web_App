package com.hgsplanet.userservice.model;

import lombok.Data;

@Data
public class PostLike {
    private String postId;
    private String username;
}
