package com.hgsplanet.commentservice.model;

import lombok.Data;


@Data
public class Post {
    private String postId;
    private String postDescription;
    private String postImgPath;
}
