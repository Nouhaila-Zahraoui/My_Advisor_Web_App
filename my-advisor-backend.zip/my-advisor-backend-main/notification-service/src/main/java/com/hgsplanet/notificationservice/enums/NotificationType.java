package com.hgsplanet.notificationservice.enums;

public enum NotificationType {
    ALERT,
    MESSAGE
}
