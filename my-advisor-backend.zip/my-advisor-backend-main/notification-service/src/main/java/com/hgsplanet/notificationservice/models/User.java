package com.hgsplanet.notificationservice.models;

import lombok.Data;

@Data
public class User {
    private String accountId;
    private String username;
    private String profileImgPath;
}
